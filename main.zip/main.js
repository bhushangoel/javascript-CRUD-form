class Node {
    constructor(data) {
        this.data = data;
        this.next = null;
    }
}

class Head {
    constructor(head = null) {
        this.head = head;
    }

    getSize() {
        let node = this.head;
        let size = 0;
        while(node) {
            size+=1;
            node = node.next;
        }
        return size;
    }

    getFirst() {
        return this.head;
    }

    getLast() {
        let node = this.head;
        while(node.next) {
            node = node.next;
        }
        return node;
    }

    printListInArray() {
        let node = this.head;
        let arr = [];
        while(node) {
            arr.push(node.data);
            node = node.next;
        }
        return arr;
    }

    printLisRecursively(node) {
        if(node === null) {
            return;
        }
        console.log(node.data);
        this.printLisRecursively(node.next);
    }

    insertAtBeginning(node) {
        if(this.head == null) {
            this.head = node;
            return this.head;
        }
        let temp = this.head;
        this.head = node;
        node.next = temp;
        return this.head
    }
    insertAtEnd(node){
        if(this.head == null) {
            this.head = node;
            return this.head;
        }
        let curr = this.head;
        while(curr.next){
            curr = curr.next;
        }
        curr.next = node;
        return  this.head;
    }
}

let n1 = new Node(10);
let n2 = new Node(20);
let n3 = new Node(35);
let n4 = new Node(40);
let n5 = new Node(50);
let n6 = new Node(60);
let n7 = new Node(5);
// let n7 = new Node(70);
// n1.next = n2;
// n2.next = n3;
// n3.next = n4;
// n4.next = n5;
// n5.next = n2;

let head = new Head(n1);
head.insertAtBeginning(n2)
head.insertAtBeginning(n3)
head.insertAtBeginning(n4)
head.insertAtBeginning(n5)
console.log(head)
console.log(head.getSize())
console.log(head.getFirst())
console.log(head.getLast())
console.log(head.printListInArray())
head.insertAtBeginning(n6)

console.log(head.printListInArray())
head.insertAtEnd(n7)
console.log(head.printListInArray())
// console.log(head.printLisRecursively(head.head));

